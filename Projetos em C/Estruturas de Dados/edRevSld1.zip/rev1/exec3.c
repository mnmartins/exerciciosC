#include <stdio.h>

int main() {

	printf("quanto dinheio vc tem?\n");
	float dinheiro = 0;
	scanf("%f" , &dinheiro);
	if(dinheiro > 50) {
		printf("va ao cinema\n");
	} else {
		printf("pobre, nao va ao cinema\n");
	}

	return 0;
}
