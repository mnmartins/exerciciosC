#include <stdio.h>

int main() {

	float num1 = 0 , num2 = 0 , media = 0;
	printf("digite dois numeros: \n");
	scanf("%f %f" , &num1 , &num2);
	media = (num1+num2) / 2;
	printf("a media e: %f\n", media);

	return 0;
}
