#include <stdio.h>

int main() {

	printf("digite o valor do raio de uma circunferencia:\n");
	float raio = 0 , area = 0;
	scanf("%f" , &raio);
	area = 3.14 * (raio * raio);
	if(raio < 0) {
		printf("raio invalido\n");
	} else if(raio >= 0 && raio < 10){
		printf("raio muito pequeno");
	} else {
		printf("a area da circunferencia e: %f\n" , area);
	}
	return 0;
}
