#include <stdio.h>
#include <stdlib.h>

int main ()
{

    int x;

    x = 15;

    printf("CONTEUDO de X = %d \n", x);
    printf("ENDERECO de X = %d \n", &x);

    return 0;
}
